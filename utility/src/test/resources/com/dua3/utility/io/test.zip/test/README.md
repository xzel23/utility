Test data for IoUtil.zip()
==========================

This folder contains some files for testing the different IoUtil.zip() methods.
